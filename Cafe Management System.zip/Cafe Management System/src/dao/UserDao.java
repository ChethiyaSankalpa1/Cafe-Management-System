package dao;

import model.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class UserDao {

    public static void save(User user) {
        String query = "INSERT INTO user (name, email, mobileNumber, address, password, security, answer, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getMobileNumber());
            ps.setString(4, user.getAddress());
            ps.setString(5, user.getPassword());
            ps.setString(6, user.getSecurity());
            ps.setString(7, user.getAnswer());
            ps.setString(8, "false");
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registered Successfully! Wait for Admin Approval.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error saving user: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static User login(String email, String password) {
        User user = null;
        String query = "SELECT * FROM user WHERE email = ? AND password = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setStatus(rs.getString("status"));
            } else {
                JOptionPane.showMessageDialog(null, "Invalid email or password!");
            }
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error during login: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return user;
    }

    public static User getSecurity(String email) {
        User user = null;
        String query = "SELECT * FROM user WHERE email = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                user = new User();
                user.setEmail(rs.getString("email"));
                user.setSecurity(rs.getString("security"));
                user.setAnswer(rs.getString("answer"));
            }
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching security details: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return user;
    }

    public static void update(String email, String newPassword) {
        String query = "UPDATE user SET password = ? WHERE email = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, newPassword);
            ps.setString(2, email);

            int updatedRows = ps.executeUpdate();
            if (updatedRows > 0) {
                JOptionPane.showMessageDialog(null, "Password updated successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Error: Email not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error updating password: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static ArrayList<User> getAllRecords(String email) {
        ArrayList<User> arrayList = new ArrayList<>();
        String query = "SELECT * FROM user WHERE email LIKE ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, "%" + email + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setMobileNumber(rs.getString("mobileNumber"));
                user.setAddress(rs.getString("address"));
                user.setSecurity(rs.getString("security"));
                user.setStatus(rs.getString("status"));
                arrayList.add(user);
            }
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching users: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return arrayList;
    }

    public static void changeStatus(String email, String status) {
        String query = "UPDATE user SET status = ? WHERE email = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, status);
            ps.setString(2, email);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Status changed successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error changing status: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void changeSecurity(String email, String password, String security, String answer) {
        String query = "SELECT * FROM user WHERE email = ? AND password = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                updateSecurity(email, security, answer);
            } else {
                JOptionPane.showMessageDialog(null, "Password is incorrect!");
            }
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error changing security: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void updateSecurity(String email, String security, String answer) {
        String query = "UPDATE user SET security = ?, answer = ? WHERE email = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, security);
            ps.setString(2, answer);
            ps.setString(3, email);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Security question changed successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error updating security: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void changePassword(String email, String oldPassword, String newPassword) {
    String query = "SELECT * FROM user WHERE email = ? AND password = ?";
    try (Connection con = ConnectionProvider.getCon();
         PreparedStatement ps = con.prepareStatement(query)) {
        ps.setString(1, email);
        ps.setString(2, oldPassword);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            String updateQuery = "UPDATE user SET password = ? WHERE email = ?";
            try (PreparedStatement updatePs = con.prepareStatement(updateQuery)) {
                updatePs.setString(1, newPassword);
                updatePs.setString(2, email);
                int rowsUpdated = updatePs.executeUpdate();
                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(null, "Password updated successfully!");
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Invalid old password!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        rs.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
    }
}
}