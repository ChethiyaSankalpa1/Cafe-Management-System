package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionProvider {

    private static final String URL = "jdbc:mysql://localhost:3306/cms";
    private static final String USER = "root";
    private static final String PASSWORD = "1234";
    private static final Logger LOGGER = Logger.getLogger(ConnectionProvider.class.getName());

    public static Connection getCon() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Database connection error: {0}", e.getMessage());
            return null;
        }
    }
}