package dao;

import javax.swing.JOptionPane;
import java.sql.*;
import model.Bill;
import java.util.ArrayList;

public class BillDao {

    public static String getId() {
        int id = 1;
        String query = "SELECT MAX(id) FROM bill";
        try (Connection con = ConnectionProvider.getCon();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            if (rs.next()) {
                id = rs.getInt(1) + 1;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return String.valueOf(id);
    }

    public static void save(Bill bill) {
        String query = "INSERT INTO bill (id, name, mobileNumber, email, date, total, createdBy) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, bill.getId());
            pst.setString(2, bill.getName());
            pst.setString(3, bill.getMobileNumber());
            pst.setString(4, bill.getEmail());
            pst.setString(5, bill.getDate());
            pst.setString(6, bill.getTotal());
            pst.setString(7, bill.getCreatedBy());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Bill Details Added Successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saving bill: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static ArrayList<Bill> getAllRecordsByInc(String date) {
        ArrayList<Bill> arrayList = new ArrayList<>();
        String query = "SELECT * FROM bill WHERE date LIKE ? ORDER BY id ASC";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, "%" + date + "%");
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    Bill bill = new Bill();
                    bill.setId(rs.getInt("id"));
                    bill.setName(rs.getString("name"));
                    bill.setMobileNumber(rs.getString("mobileNumber"));
                    bill.setEmail(rs.getString("email"));
                    bill.setDate(rs.getString("date"));
                    bill.setTotal(rs.getString("total"));
                    bill.setCreatedBy(rs.getString("createdBy"));
                    arrayList.add(bill);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching bills: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return arrayList;
    }

    public static ArrayList<Bill> getAllRecordsByDesc(String date) {
        ArrayList<Bill> arrayList = new ArrayList<>();
        String query = "SELECT * FROM bill WHERE date LIKE ? ORDER BY id DESC";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, "%" + date + "%");
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    Bill bill = new Bill();
                    bill.setId(rs.getInt("id"));
                    bill.setName(rs.getString("name"));
                    bill.setMobileNumber(rs.getString("mobileNumber"));
                    bill.setEmail(rs.getString("email"));
                    bill.setDate(rs.getString("date"));
                    bill.setTotal(rs.getString("total"));
                    bill.setCreatedBy(rs.getString("createdBy"));
                    arrayList.add(bill);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching bills: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return arrayList;
    }
}