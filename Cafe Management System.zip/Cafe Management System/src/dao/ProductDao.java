package dao;

import model.Product;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.*;

public class ProductDao {

    public static void save(Product product) {
        String query = "INSERT INTO product (name, category, price) VALUES (?, ?, ?)";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, product.getName());
            ps.setString(2, product.getCategory());
            ps.setString(3, product.getPrice());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Product added successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saving product: " + e.getMessage());
        }
    }

    public static ArrayList<Product> getAllRecords() {
        ArrayList<Product> arrayList = new ArrayList<>();
        String query = "SELECT * FROM product";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setCategory(rs.getString("category"));
                product.setPrice(rs.getString("price"));
                arrayList.add(product);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching all products: " + e.getMessage());
        }
        return arrayList;
    }

    public static void update(Product product) {
        String query = "UPDATE product SET name = ?, category = ?, price = ? WHERE id = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, product.getName());
            ps.setString(2, product.getCategory());
            ps.setString(3, product.getPrice());
            ps.setInt(4, product.getId());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Product updated successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error updating product: " + e.getMessage());
        }
    }

    public static void delete(String id) {
        String query = "DELETE FROM product WHERE id = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Product deleted successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error deleting product: " + e.getMessage());
        }
    }

    public static ArrayList<Product> getAllRecordByCategory(String category) {
        ArrayList<Product> arrayList = new ArrayList<>();
        String query = "SELECT * FROM product WHERE category = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, category);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product();
                    product.setName(rs.getString("name"));
                    arrayList.add(product);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching products by category: " + e.getMessage());
        }
        return arrayList;
    }

    public static ArrayList<Product> filterProductByName(String name, String category) {
        ArrayList<Product> arrayList = new ArrayList<>();
        String query = "SELECT * FROM product WHERE name LIKE ? AND category = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, "%" + name + "%");
            ps.setString(2, category);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product();
                    product.setName(rs.getString("name"));
                    arrayList.add(product);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error filtering products: " + e.getMessage());
        }
        return arrayList;
    }

    public static Product getProductByName(String name) {
        Product product = new Product();
        String query = "SELECT * FROM product WHERE name = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    product.setName(rs.getString("name"));
                    product.setCategory(rs.getString("category"));
                    product.setPrice(rs.getString("price"));
                } else {
                    JOptionPane.showMessageDialog(null, "Product not found");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching product by name: " + e.getMessage());
        }
        return product;
    }
}