package common;

import java.io.File;
import java.io.IOException;
import java.awt.Desktop;
import javax.swing.JOptionPane;

public class openpdf {
    public static void openById(String id) {
        try {
            String path = System.getProperty("user.home") + "\\Documents\\CafeBills\\" + id + ".pdf";
            File file = new File(path);
            if (file.exists()) {
                Desktop.getDesktop().open(file);
            } else {
                JOptionPane.showMessageDialog(null, "File does not exist", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error opening file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}